package main

import (
    "encoding/json"
    "fmt"
    "time"
    
    "github.com/hyperledger/fabric-contract-api-go/contractapi"
)

type FoodTrace struct {
    contractapi.Contract
}

type TraceRecord struct {
    ProductID  string    `json:"productId"`
    Timestamp  time.Time `json:"timestamp"`
    Status     string    `json:"status"`
}

func (ft *FoodTrace) BindRFIDToProduct(ctx contractapi.TransactionContextInterface, rfidID string, productID string) error {
    record := TraceRecord{
        ProductID: productID,
        Timestamp: time.Now(),
        Status:    "ACTIVE",
    }
    
    recordJSON, err := json.Marshal(record)
    if err != nil {
        return err
    }
    
    return ctx.GetStub().PutState(rfidID, recordJSON)
}

func (ft *FoodTrace) GetProductTrace(ctx contractapi.TransactionContextInterface, rfidID string) (*TraceRecord, error) {
    recordJSON, err := ctx.GetStub().GetState(rfidID)
    if err != nil {
        return nil, fmt.Errorf("failed to read record: %v", err)
    }
    if recordJSON == nil {
        return nil, fmt.Errorf("record not found for rfid: %s", rfidID)
    }
    
    var record TraceRecord
    err = json.Unmarshal(recordJSON, &record)
    if err != nil {
        return nil, err
    }
    
    return &record, nil
}

func main() {
    chaincode, err := contractapi.NewChaincode(&FoodTrace{})
    if err != nil {
        fmt.Printf("Error creating chaincode: %v\n", err)
        return
    }
    
    if err := chaincode.Start(); err != nil {
        fmt.Printf("Error starting chaincode: %v\n", err)
    }
}
